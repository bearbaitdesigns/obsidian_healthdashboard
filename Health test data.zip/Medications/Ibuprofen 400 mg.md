---
entry: "medication"
name: "Ibuprofen"
strength: "400 mg"
form: "Tablet"
kind: "Over the counter"
dose: "1 tablet"
schedule: "As needed"
purpose:
  - "Pain"
  - "Period cramps"
instructions: "With food"
started: "2024-12-12"
tags:
  - "health-test-data"
---
