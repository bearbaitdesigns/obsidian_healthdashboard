---
entry: "medication"
name: "Amlodipine"
strength: "5 mg"
form: "Tablet"
kind: "Prescription"
dose: "1 tablet"
schedule: "Once a day"
times:
  - "Morning"
purpose:
  - "Blood pressure"
prescriber: "Dr. Sigrún Jónsdóttir"
pharmacy: "Lyfja Smáralind"
started: "2026-08-04"
refill_date: "2026-11-16"
tags:
  - "health-test-data"
---
