---
entry: "medication"
name: "Sumatriptan"
strength: "50 mg"
form: "Tablet"
kind: "Prescription"
dose: "1 tablet"
schedule: "As needed"
purpose:
  - "Migraine relief"
instructions: "At the start of a migraine. May repeat after 2 hours. Max 2 a day."
prescriber: "Dr. Ari Magnússon"
started: "2025-10-08"
refill_date: "2026-11-10"
tags:
  - "health-test-data"
---
