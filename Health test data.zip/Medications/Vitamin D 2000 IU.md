---
entry: "medication"
name: "Vitamin D"
strength: "2000 IU"
form: "Capsule"
kind: "Supplement"
dose: "1 capsule"
schedule: "Once a day"
times:
  - "Morning"
purpose:
  - "Low vitamin D"
started: "2026-05-06"
tags:
  - "health-test-data"
---
