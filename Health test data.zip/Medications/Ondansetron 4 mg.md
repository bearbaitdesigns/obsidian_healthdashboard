---
entry: "medication"
name: "Ondansetron"
strength: "4 mg"
form: "Tablet"
kind: "Prescription"
dose: "1 tablet"
schedule: "As needed"
purpose:
  - "Nausea"
prescriber: "Dr. Ari Magnússon"
started: "2026-06-25"
tags:
  - "health-test-data"
---
