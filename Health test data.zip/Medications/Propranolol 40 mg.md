---
entry: "medication"
name: "Propranolol"
strength: "40 mg"
form: "Tablet"
kind: "Prescription"
dose: "1 tablet"
schedule: "Twice a day"
times:
  - "Morning"
  - "Evening"
purpose:
  - "Migraine prevention"
prescriber: "Dr. Ari Magnússon"
started: "2025-12-17"
stopped: "2026-06-20"
stop_reason: "Side effects"
side_effects: "Tiredness and cold hands"
tags:
  - "health-test-data"
---
