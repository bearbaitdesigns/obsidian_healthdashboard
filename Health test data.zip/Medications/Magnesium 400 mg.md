---
entry: "medication"
name: "Magnesium"
strength: "400 mg"
form: "Tablet"
kind: "Supplement"
dose: "1 tablet"
schedule: "Once a day"
times:
  - "Bedtime"
purpose:
  - "Migraine prevention"
started: "2026-02-25"
tags:
  - "health-test-data"
---
