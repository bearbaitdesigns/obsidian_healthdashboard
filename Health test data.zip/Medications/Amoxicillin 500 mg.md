---
entry: "medication"
name: "Amoxicillin"
strength: "500 mg"
form: "Capsule"
kind: "Prescription"
dose: "1 capsule"
schedule: "Three times a day"
times:
  - "Morning"
  - "Afternoon"
  - "Evening"
purpose:
  - "Sinus infection"
prescriber: "Dr. Sigrún Jónsdóttir"
started: "2026-10-11"
stopped: "2026-10-18"
stop_reason: "Course finished"
tags:
  - "health-test-data"
---
