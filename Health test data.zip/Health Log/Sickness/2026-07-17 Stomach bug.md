---
entry: "illness"
start: "2026-07-17"
end: "2026-07-18"
type: "Stomach bug"
severity: "Moderate"
symptoms:
  - "Nausea"
  - "Vomiting"
  - "Diarrhea"
temp_max: 37.9
temp_unit: "C"
medications:
  - "Oral rehydration salts"
remedies:
  - "Rest"
  - "Bland food"
helped:
  - "Oral rehydration salts"
saw_doctor: false
days_missed: 1
tags:
  - "health-test-data"
---
