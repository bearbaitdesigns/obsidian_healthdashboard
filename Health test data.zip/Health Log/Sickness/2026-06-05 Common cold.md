---
entry: "illness"
start: "2026-06-05"
end: "2026-06-08"
type: "Common cold"
severity: "Mild"
symptoms:
  - "Runny or blocked nose"
  - "Sore throat"
  - "Sneezing"
remedies:
  - "Honey and lemon"
  - "Steam inhalation"
helped:
  - "Honey and lemon"
saw_doctor: false
days_missed: 0
tags:
  - "health-test-data"
---
