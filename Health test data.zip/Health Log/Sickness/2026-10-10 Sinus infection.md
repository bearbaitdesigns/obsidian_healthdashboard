---
entry: "illness"
start: "2026-10-10"
end: "2026-10-15"
type: "Sinus infection"
severity: "Moderate"
symptoms:
  - "Runny or blocked nose"
  - "Headache"
  - "Facial pain"
temp_max: 37.8
temp_unit: "C"
medications:
  - "Amoxicillin"
  - "Saline spray"
remedies:
  - "Steam inhalation"
helped:
  - "Amoxicillin"
  - "Saline spray"
saw_doctor: true
days_missed: 1
diagnosis: "Acute sinusitis"
tags:
  - "health-test-data"
---
