---
entry: "illness"
start: "2026-11-10"
type: "Sore throat"
severity: "Mild"
symptoms:
  - "Sore throat"
remedies:
  - "Honey and lemon"
saw_doctor: false
days_missed: 0
tags:
  - "health-test-data"
---
