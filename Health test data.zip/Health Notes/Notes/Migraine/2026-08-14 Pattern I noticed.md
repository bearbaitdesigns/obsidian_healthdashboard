---
entry: "health-note"
tracker: "migraine"
date: "2026-08-14"
title: "Pattern I noticed"
note: "Most migraines seem to come just before or on the first day of my period."
tags:
  - "health-test-data"
---
