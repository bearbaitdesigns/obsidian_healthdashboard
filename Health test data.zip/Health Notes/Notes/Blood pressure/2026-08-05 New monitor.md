---
entry: "health-note"
tracker: "bp"
date: "2026-08-05"
title: "New monitor"
note: "Started using a validated upper-arm monitor (Omron M3). Earlier readings were from a wrist monitor."
tags:
  - "health-test-data"
---
