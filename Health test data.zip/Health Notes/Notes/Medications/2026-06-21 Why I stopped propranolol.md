---
entry: "health-note"
tracker: "meds"
date: "2026-06-21"
title: "Why I stopped propranolol"
note: "Felt exhausted and had cold hands; agreed with Dr. Magnússon to stop."
tags:
  - "health-test-data"
---
