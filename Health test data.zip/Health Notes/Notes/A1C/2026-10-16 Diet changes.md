---
entry: "health-note"
tracker: "a1c"
date: "2026-10-16"
title: "Diet changes"
note: "Cut down on sugary drinks since the summer."
tags:
  - "health-test-data"
---
