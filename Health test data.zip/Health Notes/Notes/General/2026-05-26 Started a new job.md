---
entry: "health-note"
tracker: "general"
date: "2026-05-26"
title: "Started a new job"
note: "New job with longer hours; sleeping later than usual."
tags:
  - "health-test-data"
---
