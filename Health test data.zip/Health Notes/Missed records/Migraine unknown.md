---
entry: "missed-event"
tracker: "migraine"
roughly: "Sometime in early spring"
count: 1
severity: "Severe"
tags:
  - "health-test-data"
---
