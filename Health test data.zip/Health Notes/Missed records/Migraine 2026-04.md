---
entry: "missed-event"
tracker: "migraine"
month: "2026-04"
count: 2
severity: "Moderate"
notes: "Forgot to log two migraines while travelling."
tags:
  - "health-test-data"
---
