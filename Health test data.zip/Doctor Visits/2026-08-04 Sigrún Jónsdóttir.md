---
entry: "doctor-visit"
date: "2026-08-04"
time: "11:00"
clinic: "Heilsugæslan"
doctor: "Dr. Sigrún Jónsdóttir"
specialty: "General practice"
visit_type: "In person"
reason: "Blood pressure follow-up"
related:
  - "bp"
discussed: "Two weeks of home readings, mostly above 135/85."
outcome: "Hypertension confirmed with home readings."
next_steps: "Start amlodipine 5 mg in the morning. Recheck in 6 weeks."
med_changes:
  - "Start Amlodipine 5 mg once a day"
follow_up: "2026-09-15"
tags:
  - "health-test-data"
  - "doctor-visit"
---
