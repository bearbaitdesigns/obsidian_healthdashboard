---
entry: "doctor-visit"
date: "2026-11-17"
time: "13:45"
clinic: "Landspítali"
doctor: "Dr. Ari Magnússon"
specialty: "Neurology"
visit_type: "In person"
reason: "Migraine follow-up"
related:
  - "migraine"
questions: "Is it worth trying prevention just around my period? Can I take sumatriptan with amlodipine?"
tags:
  - "health-test-data"
  - "doctor-visit"
---
