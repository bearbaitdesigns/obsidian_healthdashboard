---
entry: "doctor-visit"
date: "2026-06-20"
time: "09:15"
clinic: "Landspítali"
doctor: "Dr. Ari Magnússon"
specialty: "Neurology"
visit_type: "Video"
reason: "Side effects from propranolol"
related:
  - "migraine"
  - "meds"
discussed: "Tiredness and cold hands since starting propranolol."
outcome: "Stop propranolol."
next_steps: "Use ondansetron for nausea during attacks."
med_changes:
  - "Stop Propranolol 40 mg"
  - "Start Ondansetron 4 mg as needed"
tags:
  - "health-test-data"
  - "doctor-visit"
---
