---
entry: "doctor-visit"
date: "2026-05-11"
time: "14:00"
clinic: "Landspítali"
doctor: "Dr. Ari Magnússon"
specialty: "Neurology"
visit_type: "In person"
reason: "Migraine review"
related:
  - "migraine"
discussed: "Migraines 4–5 a month, often around my period. Propranolol makes me tired."
outcome: "Probable menstrually related migraine. Keep a diary for 3 cycles."
next_steps: "Track migraines and periods. Try magnesium. Review in 3 months."
med_changes:
  - "Start Magnesium 400 mg at bedtime"
follow_up: "2026-08-09"
tags:
  - "health-test-data"
  - "doctor-visit"
---
