# Health Dashboard test data

About 7 months of made-up records (April 2 – November 12, 2026) for every dashboard. Nothing here is real.

| Dashboard | What's included |
|---|---|
| Period | 8 periods with cycles of 26–38 days (one long 38-day cycle and one 8-day period, so the "patterns to discuss" flags show), flow, pain, symptoms and medication |
| Migraine | 21 migraines: types, pain 2–5, aura on some, triggers, relief, head location, time of day, medications with how well they helped. Many start around period day 1, and one is still in progress |
| Blood pressure | About 350 morning and evening readings. Readings improve after Amlodipine starts in August, and there is one very high reading in June |
| Sickness | 6 sicknesses (flu, cold, stomach bug, COVID-19, sinus infection, and a sore throat that's still going) |
| Medications | 6 current and 2 stopped, with schedules, refill dates and reasons for stopping |
| A1C | 5 results every 3 months, from 6.4% down to 5.8% |
| Doctor visits | 8 past visits with what was discussed, results, medication changes and follow-ups, plus 1 upcoming visit |
| Notes | 7 general and tracker notes, 2 migraines and 1 period logged without an exact date |

## How to use it

1. Best: make a new, empty test vault in Obsidian and install Health Dashboard there.
2. Copy every folder in this zip into the root of the vault. The folder names match Health Dashboard's default folders, so they're picked up straight away.
3. Open the Health dashboard.

Every note has the tag `#health-test-data`. To remove the test data from a vault you also use for real records, search for `tag:#health-test-data` and delete those notes. You can also delete the folders, but only if they hold no real notes.
